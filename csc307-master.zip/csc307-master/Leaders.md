
# Team Leaders
1. Marina Moore - Database and Time reporter
2. Nick Parra - Design and Architecture
3. Isabel Jellen - Implementation and Test
4. Robert Liu - Requirement and Analysis
5. Derek Nguyen - GUI


